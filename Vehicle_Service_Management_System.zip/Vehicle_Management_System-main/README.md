# Vehicle_Management_System
The Vehicle Management System allows providing a variety of services to the organization.
This project helps the organization to reduce manual work.
The real power of this project lies not in modules, but the creation of tighter and transparent relationships with users/
drivers/employees and delivering a high level of service and support, which in turn
improves organization time and money
