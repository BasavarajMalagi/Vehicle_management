package vehicle_management;

public @interface Singleton {

}
